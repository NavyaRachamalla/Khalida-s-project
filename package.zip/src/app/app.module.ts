import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { ViewTaskComponent } from './view-task/view-task.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {FilterPipe} from './filter.pipe';
import {TaskFilterPipe} from './view-task/task-filter.pipe';
import {ParentFilterPipe} from './view-task/parent-filter.pipe';
import {StartFilterPipe} from './view-task/start-filter.pipe';
import {EndFilterPipe} from './view-task/end-filter.pipe';
import {FromFilterPipe} from './view-task/from-filter.pipe';
import {ToFilterPipe} from './view-task/to-filter.pipe';
import { UpdateTaskComponent } from './update-task/update-task.component';
import {HttpClientModule} from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';
import { NgxDeleteConfirmModule } from 'ngx-delete-confirm';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MyModalComponent } from './my-modal/my-modal.component';
import { ModalDialogModule } from 'ngx-modal-dialog';

@NgModule({
  declarations: [
    AppComponent,
    AddTaskComponent,
    ViewTaskComponent,
    TaskFilterPipe,
    ParentFilterPipe,
    StartFilterPipe,
    EndFilterPipe,
    FromFilterPipe,
    ToFilterPipe,
    UpdateTaskComponent,
    MyModalComponent,
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    NgxDeleteConfirmModule.forRoot(),
    NgbModule.forRoot(),
    ModalDialogModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

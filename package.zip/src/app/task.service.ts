import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Task} from './models/add-task';


import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http: HttpClient) { }
  public getTasks() {
 
    return this.http.get<Task[]>('http://localhost:1235/tmc/task/findall');
  }

  public createTask(task){

    return this.http.post('http://localhost:1235/tmc/task/save',task, { responseType: 'text' as 'text'});
  }

  public updateTask(task){
     
     return this.http.put('http://localhost:1235/tmc/task/update',task,{responseType: 'text' as 'text'});
  }

  public deleteTask(task){
    
    return this.http.delete('http://localhost:1235/tmc/task/delete',task);
  }

 

}

export interface iTask{
     task_id:any;
    parenttask:any;
    task:any;
    start_date:any;
    end_date:any;
    priority:number;
    //filter(tsk:iTask):iTask;
}
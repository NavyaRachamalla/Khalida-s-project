import { iTask} from './itask';
   import {  PipeTransform, Pipe } from '@angular/core';


@Pipe({
    name: 'parentFilter'
})
   export class ParentFilterPipe implements PipeTransform {
   transform(value: iTask[], filterBy: any): iTask[] {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        return filterBy ? value.filter((plan: iTask) =>
           plan.parenttask .toLocaleLowerCase().indexOf(filterBy) !== -1) : value;
    }
   } 
import { iTask} from './itask';
   import {  PipeTransform, Pipe } from '@angular/core';


@Pipe({
    name: 'taskFilter'
})
   export class TaskFilterPipe implements PipeTransform {
   transform(value: iTask[], filterBy: any): iTask[] {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        return filterBy ? value.filter((plan: iTask) =>
           plan.task .toLocaleLowerCase().indexOf(filterBy) !== -1) : value;
    }
   } 
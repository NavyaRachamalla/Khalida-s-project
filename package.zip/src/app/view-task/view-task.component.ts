import { Component, OnInit } from '@angular/core';
import {iTask} from './itask';
import { filter } from 'rxjs/operators';
import {FormGroup,FormBuilder,FormControl} from '@angular/forms';
import {TaskService} from '../task.service';
import {Task} from '../models/add-task';



@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {
  //add:new AddTaskComponent();
  taskForm:FormGroup;
  
message='none';
 
 public vars : Task[];

//_task: string;
_priorityfrom:string;
_parent:string;
_priorityto:string;
_startdate:string;
_enddate:string;
/*get task(): string {
return this._task;
}
set task(value: string) {
this._task = value;}*/
//this.filteredTasks = this.task ? this.performFilter(this.task) : this.tasks;
/*if(this.task){
  this.performFilter(this.task);
}
else{
  this.filteredTasks=this.tasks;
}
}*/

//filteredTasks: iTask[] = [];

//tasks:iTask[];



  constructor(private fb :FormBuilder,private vs:TaskService) {
  // this.task='';
   }

  ngOnInit() {
  this.vs.getTasks().subscribe(data=>{
    this.vars=data;
    console.log(this.vars);
  });


 /* const values =   sessionStorage.getItem("pushedVales");
  this.vars = JSON.parse(values);
  console.log(this.vars);*/
 

this.taskForm=this.fb.group({
  task:[''], parent:[''], priorityfrom:[''], priorityto:[''], startdate:[''], enddate:['']
  
})

 //this.tasks.push(this.vars);
 //this.tasks=this.vars;
  /*  tasks => {
this.tasks = tasks;

}*/
  }
/*performFilter(filterBy : string) :void{
 //alert(); 
 //var a:string ="ABVGHDJHGD";
 //console.log(a.toLocaleLowerCase());
 //console.log(this.tasks);
//filterBy = filterBy.toLocaleLowerCase();
//console.log("its in");
//console.log(filterBy);

this.filteredTasks=( this.tasks.filter((tsk: iTask) =>
tsk.task.indexOf(filterBy) !== -1));
//console.log(this.filteredTasks);
this.vars=this.filteredTasks;
//return this.filteredTasks;
} */
public closeModalDialog() {
  alert(this.vars.task);
  this.message="hi";
  }
 
}

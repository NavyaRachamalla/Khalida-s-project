import { iTask} from './itask';
   import {  PipeTransform, Pipe } from '@angular/core';


@Pipe({
    name: 'startFilter'
})
   export class StartFilterPipe implements PipeTransform {
   transform(value: iTask[], filterBy: any): iTask[] {
        //filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        return filterBy ? value.filter((plan: iTask) =>
           plan.start_date .indexOf(filterBy) !== -1) : value;
    }
   } 
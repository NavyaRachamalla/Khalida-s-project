import { Component, OnInit } from '@angular/core';
import { IModalDialog, IModalDialogOptions,IModalDialogButton } from 'ngx-modal-dialog';

@Component({
  selector: 'app-my-modal',
  templateUrl: './my-modal.component.html',
  styleUrls: ['./my-modal.component.css']
})
export class MyModalComponent implements OnInit {
actionButtons: IModalDialogButton[];
  constructor() {

     
   }
ngOnInit(){}



}

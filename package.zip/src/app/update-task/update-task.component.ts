import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,FormControl} from '@angular/forms';
import {TaskService} from '../task.service';
import {Router} from '@angular/router';
import {Task} from '../models/add-task';


@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent implements OnInit {
 updateForm:FormGroup;
 message:string;
  constructor(private fb :FormBuilder,private vs:TaskService,private router:Router) { }

  ngOnInit() {

    this.updateForm=this.fb.group({
  task:[''],  priority:[''], parenttask:[''], start_date:[''], end_date:['']
  
})
  }

  public pushVal(){
 /*var obj = {
    "task": this.task,
    "parent":this.parenttask,
    "priority":this.priority,
    "start_date":this.startdate,
    "end_date":this.enddate
 }


   this.pushVales.push(obj);
   sessionStorage.setItem("pushedVales",JSON.stringify(this.pushVales));
  console.log(this.pushVales);*/
console.log(this.updateForm.value);
  this.vs.updateTask(this.updateForm.value)
    .subscribe( data => {   
      
      
        this.message=data;
    });
}

}

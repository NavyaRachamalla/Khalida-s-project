import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,FormControl} from '@angular/forms';
import {TaskService} from '../task.service';
import {Router} from '@angular/router';
import {Task} from '../models/add-task';


@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  addForm:FormGroup;
  tasks:Task[];
  message:string;
  /*public task:any;
  public enddate:any;
  public startdate:any;
  public parenttask:any;
  public priority:number;
  
  public pushVales:any = [];*/
  constructor(private fb :FormBuilder,private vs:TaskService,private router:Router) { }
  
  ngOnInit() {
    this.addForm=this.fb.group({
  task:[''],  priority:[''], parenttask:[''], start_date:[''], end_date:['']
  
})
  }

public pushVal(){
 /*var obj = {
    "task": this.task,
    "parent":this.parenttask,
    "priority":this.priority,
    "start_date":this.startdate,
    "end_date":this.enddate
 }


   this.pushVales.push(obj);
   sessionStorage.setItem("pushedVales",JSON.stringify(this.pushVales));
  console.log(this.pushVales);*/
console.log(this.addForm.value);
  this.vs.createTask(this.addForm.value)
    .subscribe( data => {   
      
      
        this.message=data;
    });
}

}

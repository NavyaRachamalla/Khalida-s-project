export class Task{
    task_id:String;
    parent_id:String;
    task:String;
    start_date:String;
    end_date:String;
    priority:number;
    parenttask:String;
}